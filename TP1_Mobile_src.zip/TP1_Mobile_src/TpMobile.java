//programme d'un mobile se deplacant de la gauche vers la droite de la fenetre-ecran
import java.awt.*;
import javax.swing.*;

public class TpMobile
{
    public static void main(String[] telsArgs) 
    {
	new UneFenetre();
 	
    }
}
